﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAppModel.Models;
using WebAppModel.ViewModels;

namespace WebAppModel.Controllers
{
    public class HomeController : Controller
    {
        
        public IActionResult Index()
        {
            #region ViewBagTempData
            //ViewBag.Name = "Ibrahim";
            //ViewBag.Surname = "Aslanli";
            //TempData["Age"] = 20;
            //return RedirectToAction(nameof(Test));
            #endregion

            string fullname = "Xeyal Binnetov";

            List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };

            List<Student> students = new List<Student>
            {
                new Student{Id=1,Name="Ulvi",Surname="Qarazade"},
                new Student{Id=2,Name="Fereh",Surname="Esgerova"},
                new Student{Id=3,Name="Elnare",Surname="Sadiqli"},
            };

            HomeViewModel model = new HomeViewModel
            {
                Students = students,
                Numbers = numbers,
                Fullname= fullname
            };

            return View(model);
        }

        public IActionResult Test()
        {
            return View();
        }
    }
}
