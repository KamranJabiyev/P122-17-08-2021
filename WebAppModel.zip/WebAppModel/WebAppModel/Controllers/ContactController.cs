﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppModel.Views.Home
{
    public class ContactController : Controller
    {
        public IActionResult Index(int id)
        {
            //string id = HttpContext.Request.Query["id"];
            //string id = (string)RouteData.Values["id"];
            //string con =(string) RouteData.Values["controller"];
            return Content("id: " + id);
        }
    }
}
